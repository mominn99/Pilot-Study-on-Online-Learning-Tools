# Impact of COVID-19 on education: A Pilot study 

We have conducted a survey and made recommendations to improve education in CoVID-19.

This repository contain three csv files.

Online Tools.csv contain student data

For Faculty.csv contain faculty data

institute.csv contain institue data with frequency.
